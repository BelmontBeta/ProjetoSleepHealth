package com.example.telastroca;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.sql.DriverPropertyInfo;

public class ControleDoSono extends Activity {

    Button btDesconectar;
    Intent ControleDoSono;
    private DriverPropertyInfo campousuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controle_do_sono);
        btDesconectar = findViewById(R.id.btDesconectar);

        btDesconectar.setOnClickListener(view -> {
            ControleDoSono = new Intent(ControleDoSono.this, MainActivity.class);
            startActivity(ControleDoSono);
        });
    }
}