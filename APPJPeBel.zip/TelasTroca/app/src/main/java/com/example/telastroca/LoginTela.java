package com.example.telastroca;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import java.sql.DriverPropertyInfo;


public class LoginTela extends Activity {

    Button btLogar;
    Button btMenu;
    Intent ControleDoSono;
    private DriverPropertyInfo campousuario;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_tela);
        btLogar = findViewById(R.id.btLogar);
        btMenu = findViewById(R.id.btMenu);

        btLogar.setOnClickListener(view -> {
            ControleDoSono = new Intent( LoginTela.this, ControleDoSono.class);
            startActivity(ControleDoSono);
        });

        btMenu.setOnClickListener(view -> LoginTela.this.finish());




    }
}