package com.example.telastroca;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity {

    Button btLogin, btCadastro;
    Intent iTelaLogin, CriarCadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btLogin = (Button) findViewById(R.id.btLogin);
        btCadastro = (Button) findViewById(R.id.btcadastro);

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iTelaLogin = new Intent(MainActivity.this, LoginTela.class);
                startActivity(iTelaLogin);
            }
        });

        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CriarCadastro = new Intent(MainActivity.this, CriarCadastro.class);
                startActivity(CriarCadastro);
            }
        });

    }
}